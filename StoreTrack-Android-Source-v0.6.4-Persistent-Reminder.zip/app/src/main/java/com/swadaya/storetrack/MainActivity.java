package com.swadaya.storetrack;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;
import android.webkit.*;

public class MainActivity extends Activity {
  WebView web;
  static final String URL = "https://timely-blancmange-8727ee.netlify.app/";
  @Override public void onCreate(Bundle b) { super.onCreate(b); requestNotif(); createChannel();
    web = new WebView(this); web.setWebViewClient(new WebViewClient());
    web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setGeolocationEnabled(true); web.addJavascriptInterface(new Bridge(), "StoreTrackNative");
    web.setDownloadListener((url, ua, cd, mime, len) -> {
      try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if (!ok) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},42);
        cb.invoke(origin, ok, false);
      }
    }); setContentView(web); web.loadUrl(URL);
  }
  void requestNotif(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},43); }
  void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("storetrack_reminder_v2","Pengingat StoreTrack",NotificationManager.IMPORTANCE_LOW); c.setDescription("Pengingat senyap setelah 10 menit berada di luar toko"); c.setSound(null, null); c.enableVibration(false); c.setVibrationPattern(new long[]{0}); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
  class Bridge {
    @JavascriptInterface public void scheduleReminder(String reason,long due,String eventId){ ReminderScheduler.schedule(MainActivity.this,reason,due,eventId); }
    @JavascriptInterface public void cancelReminder(){ ReminderScheduler.cancel(MainActivity.this); }
    @JavascriptInterface public void notify(String title,String message){ ReminderScheduler.show(MainActivity.this,title,message); }
    @JavascriptInterface public void saveBase64File(String filename,String base64,String mimeType){
      runOnUiThread(() -> {
        try {
          byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
          ContentValues values=new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME,filename); values.put(MediaStore.Downloads.MIME_TYPE,mimeType);
          if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Downloads.IS_PENDING,1);
          Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
          if(uri==null) throw new Exception("Tidak dapat membuat file di folder Download");
          try(OutputStream out=getContentResolver().openOutputStream(uri)){ if(out==null) throw new Exception("Tidak dapat menulis file"); out.write(bytes); out.flush(); }
          if(Build.VERSION.SDK_INT>=29){ ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,done,null,null); }
          Toast.makeText(MainActivity.this,"File tersimpan di folder Download",Toast.LENGTH_LONG).show();
        }catch(Exception e){ Toast.makeText(MainActivity.this,"Gagal menyimpan: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
      });
    }
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
