package com.swadaya.storetrack;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

public final class ReminderScheduler {
    static final String PREF = "storetrack_alarm";
    static final String KEY_DUE = "due", KEY_REASON = "reason", KEY_ID = "event";
    static final String CHANNEL_ID = "storetrack_reminder_v3";
    static final int NOTIFICATION_ID = 7001;
    private static final String TAG = "StoreTrackReminder";

    private static PendingIntent alarmPendingIntent(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("com.swadaya.storetrack.SHOW_REMINDER");
        return PendingIntent.getBroadcast(c, 7001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static String schedule(Context c, String reason, long due, String id) {
        if (due <= System.currentTimeMillis()) return "Waktu pengingat tidak valid.";
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return "Izin notifikasi Android belum diberikan. Aktifkan izin Notifikasi untuk StoreTrack.";
        }
        if (!nm.areNotificationsEnabled()) return "Notifikasi StoreTrack sedang dinonaktifkan di pengaturan Android.";
        createChannel(c);
        SharedPreferences prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        boolean saved = prefs.edit().putLong(KEY_DUE, due).putString(KEY_REASON, reason == null ? "aktivitas" : reason).putString(KEY_ID, id == null ? "" : id).commit();
        if (!saved) return "Gagal menyimpan jadwal pengingat.";
        try {
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = alarmPendingIntent(c);
            am.cancel(pi);
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi);
                Log.i(TAG, "Exact alarm scheduled for " + due);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi);
                Log.w(TAG, "Exact alarm permission unavailable; scheduled allow-while-idle fallback");
            } else {
                am.set(AlarmManager.RTC_WAKEUP, due, pi);
            }
            return "OK";
        } catch (RuntimeException e) {
            Log.e(TAG, "Unable to schedule reminder", e);
            prefs.edit().remove(KEY_DUE).remove(KEY_REASON).remove(KEY_ID).commit();
            return "Gagal menjadwalkan pengingat: " + e.getClass().getSimpleName();
        }
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(alarmPendingIntent(c));
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().commit();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID);
    }

    static void restore(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        long due = p.getLong(KEY_DUE, 0);
        if (due == 0) return;
        if (due > System.currentTimeMillis()) {
            schedule(c, p.getString(KEY_REASON, "aktivitas"), due, p.getString(KEY_ID, ""));
        } else {
            showReminder(c);
        }
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Pengingat StoreTrack", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Pengingat senyap 10 menit setelah mencatat KELUAR");
            channel.setSound(null, null);
            channel.enableVibration(false);
            nm.createNotificationChannel(channel);
        }
    }

    // Generic native notification entry point used by the WebView bridge.
    // Keep the same silent, ongoing notification behavior as the reminder.
    static void show(Context c, String title, String message) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Cannot show notification: POST_NOTIFICATIONS permission missing");
            return;
        }
        if (!nm.areNotificationsEnabled()) {
            Log.e(TAG, "Cannot show notification: app notifications disabled");
            return;
        }
        createChannel(c);
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (launch == null) {
            Log.e(TAG, "Cannot show notification: launch intent unavailable");
            return;
        }
        PendingIntent contentPi = PendingIntent.getActivity(c, 1, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL_ID) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle(title == null ? "Swadaya Sarana Plastik" : title)
         .setContentText(message == null ? "Buka StoreTrack untuk melihat aktivitas." : message)
         .setStyle(new Notification.BigTextStyle().bigText(message == null ? "Buka StoreTrack untuk melihat aktivitas." : message))
         .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true)
         .setContentIntent(contentPi);
        if (Build.VERSION.SDK_INT < 26) { b.setSound(null); b.setVibrate(new long[]{0}); b.setPriority(Notification.PRIORITY_LOW); }
        Notification notification = b.build();
        notification.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
        nm.notify(NOTIFICATION_ID, notification);
        Log.i(TAG, "Native notification posted");
    }

    static void showReminder(Context c) {
        SharedPreferences prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (prefs.getLong(KEY_DUE, 0) == 0) return; // MASUK already recorded.
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Cannot show reminder: POST_NOTIFICATIONS permission missing");
            return;
        }
        if (!nm.areNotificationsEnabled()) {
            Log.e(TAG, "Cannot show reminder: app notifications disabled");
            return;
        }
        createChannel(c);
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (launch == null) return;
        PendingIntent contentPi = PendingIntent.getActivity(c, 1, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String reason = prefs.getString(KEY_REASON, "aktivitas");
        String msg = "Sudah 10 menit sejak kamu keluar untuk: " + reason + ". Buka StoreTrack dan catat MASUK jika sudah kembali.";
        Intent dismissed = new Intent(c, ReminderReceiver.class);
        dismissed.setAction(ReminderReceiver.ACTION_REMINDER_DISMISSED);
        PendingIntent deletePi = PendingIntent.getBroadcast(c, 7002, dismissed, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL_ID) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("Swadaya Sarana Plastik: pengingat kembali")
         .setContentText(msg)
         .setStyle(new Notification.BigTextStyle().bigText(msg))
         .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true)
         .setContentIntent(contentPi).setDeleteIntent(deletePi);
        if (Build.VERSION.SDK_INT < 26) { b.setSound(null); b.setVibrate(new long[]{0}); b.setPriority(Notification.PRIORITY_LOW); }
        Notification notification = b.build();
        notification.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
        nm.notify(NOTIFICATION_ID, notification);
        Log.i(TAG, "Persistent reminder posted");
    }
}
