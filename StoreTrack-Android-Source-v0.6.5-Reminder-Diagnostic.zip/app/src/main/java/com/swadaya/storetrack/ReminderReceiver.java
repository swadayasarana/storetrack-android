package com.swadaya.storetrack;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_REMINDER_DISMISSED = "com.swadaya.storetrack.REMINDER_DISMISSED";

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences(ReminderScheduler.PREF, 0);
        long due = prefs.getLong(ReminderScheduler.KEY_DUE, 0);

        // MASUK clears KEY_DUE. Never recreate the reminder after that.
        if (due == 0) return;

        if (ACTION_REMINDER_DISMISSED.equals(intent != null ? intent.getAction() : null)) {
            // If the user or system dismisses the reminder while the outing is still open,
            // post the same persistent notification again.
            if (System.currentTimeMillis() >= due) {
                ReminderScheduler.showReminder(context);
            }
            return;
        }

        // Alarm fired.
        if (System.currentTimeMillis() >= due) {
            ReminderScheduler.showReminder(context);
        }
    }
}
