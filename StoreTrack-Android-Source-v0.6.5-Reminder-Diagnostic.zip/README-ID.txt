STORETRACK ANDROID SOURCE — v0.6.0 (BUILD AWAN)

Ini adalah SOURCE PROJECT Android, belum APK yang sudah teruji/siap dipasang.
Aplikasi web PDF+Supabase yang sudah ada disalin ke folder web/ dan dipaketkan ke APK sebagai WebView.
URL web aktif: https://timely-blancmange-8727ee.netlify.app/

CARA BUILD DARI HP (GitHub):
1. Buat repository GitHub baru bernama StoreTrack-Android.
2. Upload seluruh ISI folder/ZIP ini ke root repository (termasuk folder .github).
3. Buka tab Actions, pilih workflow “Build StoreTrack APK”, lalu Run workflow.
4. Tunggu sampai job selesai hijau. Buka hasil Artifacts dan unduh StoreTrack-debug-apk.
5. Ekstrak ZIP artifact; file APK ada di dalamnya. Instal hanya pada perangkat sendiri.

CATATAN PENTING:
- Build ini debug APK, bukan APK Play Store/signing release.
- Alarm menggunakan Android AlarmManager setAndAllowWhileIdle (alarm dapat terlambat karena Doze/OEM battery management; tidak dijamin tepat detik). Tidak meminta izin exact-alarm khusus agar instalasi lebih sederhana.
- Alarm disimpan dan dipulihkan setelah reboot. MASUK membatalkan alarm melalui bridge.
- Izin notifikasi dan lokasi diminta oleh Android.
- Supabase tetap menggunakan konfigurasi publik yang sudah ada di web app. Jangan pernah memasukkan service_role key.
- PDF/CSV di WebView perlu diuji pada perangkat; ekspor blob dari browser mungkin memerlukan penanganan unduhan tambahan. Versi PWA web yang sekarang tetap tersedia sebagai cadangan.
- Jika status keluar sudah aktif saat halaman dibuka, JS akan menjadwalkan alarm lagi ke native bridge.
- Setelah deploy web berubah, APK akan memuat situs yang sama secara online.

Sebelum dipakai rutin: uji keluar, tutup aplikasi, tunggu 15 menit, uji notifikasi, catat MASUK, restart HP, dan uji ekspor PDF/CSV.


PEMBARUAN IKON v0.6.1
- Ikon StoreTrack baru dipasang untuk PWA/Netlify dan launcher APK Android.
- PWA memakai icons/icon-192.png, icon-512.png, dan icon-maskable-512.png.
- APK memakai resource mipmap density mdpi hingga xxxhdpi.
- Setelah update Netlify, buka ulang PWA. Jika ikon lama masih muncul, hapus shortcut lama dari layar utama lalu pasang ulang dari Chrome.
- APK hasil build baru akan memakai ikon baru; APK lama tidak berubah otomatis.

PEMBARUAN v0.6.2 — BRANDING & EKSPOR NATIVE
- Identitas yang terlihat di aplikasi/website diubah menjadi Swadaya Sarana Plastik; applicationId dan package teknis tetap dipertahankan.
- Android WebView menyediakan bridge saveBase64File untuk menyimpan PDF/CSV ke folder Download melalui MediaStore.
- Halaman web memakai bridge native bila tersedia; PWA/Chrome tetap memakai mekanisme unduh browser.
- Alarm memakai setExactAndAllowWhileIdle bila izin exact alarm sudah diberikan; bila belum, fallback tetap inexact.
- Penting: APK tetap membuka URL Netlify. Agar ekspor PDF/CSV native berfungsi di APK, deploy juga isi folder web/ ke Netlify terlebih dahulu, lalu build APK baru dari repository ini.
- Fitur akun Viewer username natasya dan dashboard live belum diaktifkan dalam paket ini. Supabase Auth yang ada masih email/password; perubahan akses harus disertai desain autentikasi dan kebijakan RLS yang aman pada project Supabase. Jangan membuat akun viewer dengan tabel password biasa atau membagikan service_role key.


PEMBARUAN PENGINGAT v0.6.3 (PERMINTAAN PENGGUNA)
- Waktu pengingat diubah menjadi 10 menit setelah KELUAR.
- Jika MASUK belum dicatat, Android menampilkan notifikasi senyap yang ongoing dan tidak auto-cancel.
- Notifikasi tetap ada setelah alarm berbunyi dan baru dibatalkan oleh bridge cancelReminder saat MASUK dicatat.
- Notifikasi dibuat tanpa suara/getaran melalui channel baru storetrack_reminder_v2.
- Android tetap dapat membatasi notifikasi/alarm melalui izin, force-stop, atau kebijakan perangkat; uji pada perangkat nyata diperlukan.
