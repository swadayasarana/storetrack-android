STORETRACK ANDROID SOURCE — v0.6.0 (BUILD AWAN)

Ini adalah SOURCE PROJECT Android, belum APK yang sudah teruji/siap dipasang.
Aplikasi web PDF+Supabase yang sudah ada disalin ke folder web/ dan dipaketkan ke APK sebagai WebView.
URL web aktif: https://timely-blancmange-8727ee.netlify.app/

CARA BUILD DARI HP (GitHub):
1. Buat repository GitHub baru bernama StoreTrack-Android.
2. Upload seluruh ISI folder/ZIP ini ke root repository (termasuk folder .github).
3. Buka tab Actions, pilih workflow “Build StoreTrack APK”, lalu Run workflow.
4. Tunggu sampai job selesai hijau. Buka hasil Artifacts dan unduh StoreTrack-debug-apk.
5. Ekstrak ZIP artifact; file APK ada di dalamnya. Instal hanya pada perangkat sendiri.

CATATAN PENTING:
- Build ini debug APK, bukan APK Play Store/signing release.
- Alarm menggunakan Android AlarmManager setAndAllowWhileIdle (alarm dapat terlambat karena Doze/OEM battery management; tidak dijamin tepat detik). Tidak meminta izin exact-alarm khusus agar instalasi lebih sederhana.
- Alarm disimpan dan dipulihkan setelah reboot. MASUK membatalkan alarm melalui bridge.
- Izin notifikasi dan lokasi diminta oleh Android.
- Supabase tetap menggunakan konfigurasi publik yang sudah ada di web app. Jangan pernah memasukkan service_role key.
- PDF/CSV di WebView perlu diuji pada perangkat; ekspor blob dari browser mungkin memerlukan penanganan unduhan tambahan. Versi PWA web yang sekarang tetap tersedia sebagai cadangan.
- Jika status keluar sudah aktif saat halaman dibuka, JS akan menjadwalkan alarm lagi ke native bridge.
- Setelah deploy web berubah, APK akan memuat situs yang sama secara online.

Sebelum dipakai rutin: uji keluar, tutup aplikasi, tunggu 15 menit, uji notifikasi, catat MASUK, restart HP, dan uji ekspor PDF/CSV.
