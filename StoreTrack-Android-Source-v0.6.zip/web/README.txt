STORETRACK v0.5 — EKSPOR PDF + SUPABASE

Fitur:
- Catat KELUAR dan MASUK, kategori dan keterangan.
- GPS saat pencatatan; bila gagal, tetap mencatat tanpa koordinat.
- Riwayat, tautan Google Maps, koreksi tanggal/waktu/jenis/kategori/keterangan.
- Laporan harian, mingguan, bulanan, tahunan; durasi lintas tengah malam.
- Login, pendaftaran email/password, logout, sinkronisasi Supabase.
- Ekspor PDF berdasarkan periode laporan yang sedang dipilih (harian/mingguan/bulanan/tahunan). PDF berisi ringkasan, tanggal, jam keluar/masuk, tujuan, keterangan, dan durasi.
- Ekspor CSV tetap tersedia.
- Data lokal tetap disimpan sebagai cadangan browser.
- Pengingat 15 menit saat halaman tetap terbuka.

CARA EKSPOR PDF DI ANDROID:
1. Buka StoreTrack dan pastikan akun sudah login serta status sinkronisasi selesai.
2. Pilih periode laporan: Harian, Mingguan, Bulanan, atau Tahunan.
3. Tekan tombol Ekspor PDF pada bagian Riwayat Aktivitas.
4. PDF akan diunduh ke perangkat (biasanya folder Download).
5. Buka WhatsApp, pilih chat istri, lampirkan Dokumen, lalu pilih PDF StoreTrack yang diunduh.
PDF standar dapat dibuka di Android maupun iPhone.

PENTING:
- Ini masih PWA/web app, bukan APK Android native.
- Perlu koneksi internet saat memuat pustaka PDF dan Supabase.
- Pastikan sinkronisasi selesai sebelum ekspor agar data terbaru sudah masuk.
- Jangan memasukkan Supabase service_role/secret key ke frontend.
- Pengingat belum dijamin bekerja saat aplikasi ditutup.

PEMBARUAN:
Unggah isi ZIP v0.5 ke Netlify sebagai versi baru (Drop new files), lalu tekan Publish new version. Setelah terbit, tutup StoreTrack dan buka kembali. Jika masih versi lama, refresh halaman atau hapus cache situs.
