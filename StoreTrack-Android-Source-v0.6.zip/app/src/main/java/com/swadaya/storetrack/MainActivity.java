package com.swadaya.storetrack;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;

public class MainActivity extends Activity {
  WebView web;
  static final String URL = "https://timely-blancmange-8727ee.netlify.app/";
  @Override public void onCreate(Bundle b) { super.onCreate(b); requestNotif(); createChannel();
    web = new WebView(this); web.setWebViewClient(new WebViewClient());
    web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setGeolocationEnabled(true); web.addJavascriptInterface(new Bridge(), "StoreTrackNative");
    web.setDownloadListener((url, ua, cd, mime, len) -> {
      try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if (!ok) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},42);
        cb.invoke(origin, ok, false);
      }
    }); setContentView(web); web.loadUrl(URL);
  }
  void requestNotif(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},43); }
  void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("storetrack_reminder","Pengingat StoreTrack",NotificationManager.IMPORTANCE_HIGH); c.setDescription("Pengingat setelah 15 menit berada di luar toko"); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
  class Bridge {
    @JavascriptInterface public void scheduleReminder(String reason,long due,String eventId){ ReminderScheduler.schedule(MainActivity.this,reason,due,eventId); }
    @JavascriptInterface public void cancelReminder(){ ReminderScheduler.cancel(MainActivity.this); }
    @JavascriptInterface public void notify(String title,String message){ ReminderScheduler.show(MainActivity.this,title,message); }
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
