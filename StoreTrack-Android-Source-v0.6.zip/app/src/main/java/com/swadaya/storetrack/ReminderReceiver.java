package com.swadaya.storetrack;
import android.content.*;
public class ReminderReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ var p=c.getSharedPreferences(ReminderScheduler.PREF,0); long due=p.getLong(ReminderScheduler.KEY_DUE,0); if(due==0 || System.currentTimeMillis()<due)return; String reason=p.getString(ReminderScheduler.KEY_REASON,"aktivitas"); ReminderScheduler.show(c,"StoreTrack: pengingat kembali","Sudah 15 menit sejak kamu keluar untuk: "+reason+". Catat MASUK jika sudah kembali."); ReminderScheduler.cancel(c); } }
