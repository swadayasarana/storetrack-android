package com.swadaya.storetrack;
import android.app.*; import android.content.*; import android.os.Build;

public class ReminderScheduler {
 static final String PREF="storetrack_alarm", KEY_DUE="due", KEY_REASON="reason", KEY_ID="event";
 static PendingIntent pending(Context c){ Intent i=new Intent(c,ReminderReceiver.class); return PendingIntent.getBroadcast(c,7001,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
 static void schedule(Context c,String reason,long due,String id){
   c.getSharedPreferences(PREF,0).edit().putLong(KEY_DUE,due).putString(KEY_REASON,reason).putString(KEY_ID,id).apply();
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=pending(c); am.cancel(pi);
   if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,due,pi); else am.set(AlarmManager.RTC_WAKEUP,due,pi);
 }
 static void cancel(Context c){ ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c)); c.getSharedPreferences(PREF,0).edit().clear().apply(); }
 static void restore(Context c){ android.content.SharedPreferences p=c.getSharedPreferences(PREF,0); long due=p.getLong(KEY_DUE,0); if(due>System.currentTimeMillis()) schedule(c,p.getString(KEY_REASON,"aktivitas"),due,p.getString(KEY_ID,"")); else if(due!=0) cancel(c); }
 static void show(Context c,String title,String msg){
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
   Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName()); PendingIntent pi=PendingIntent.getActivity(c,1,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"storetrack_reminder"):new Notification.Builder(c);
   b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(pi); nm.notify(7001,b.build());
 }
}
