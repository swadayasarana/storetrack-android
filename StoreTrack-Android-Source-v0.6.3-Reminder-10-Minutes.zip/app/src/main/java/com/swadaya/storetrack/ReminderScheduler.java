package com.swadaya.storetrack;
import android.app.*; import android.content.*; import android.os.Build;

public class ReminderScheduler {
 static final String PREF="storetrack_alarm", KEY_DUE="due", KEY_REASON="reason", KEY_ID="event";
 static final int NOTIFICATION_ID=7001;
 static PendingIntent pending(Context c){ Intent i=new Intent(c,ReminderReceiver.class); return PendingIntent.getBroadcast(c,7001,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
 static void schedule(Context c,String reason,long due,String id){
   c.getSharedPreferences(PREF,0).edit().putLong(KEY_DUE,due).putString(KEY_REASON,reason).putString(KEY_ID,id).apply();
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=pending(c); am.cancel(pi);
   if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,due,pi);
   else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,due,pi); else am.set(AlarmManager.RTC_WAKEUP,due,pi);
 }
 // Called only after the user records MASUK.
 static void cancel(Context c){ ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c)); c.getSharedPreferences(PREF,0).edit().clear().apply(); ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIFICATION_ID); }
 static void restore(Context c){ android.content.SharedPreferences p=c.getSharedPreferences(PREF,0); long due=p.getLong(KEY_DUE,0); if(due>System.currentTimeMillis()) schedule(c,p.getString(KEY_REASON,"aktivitas"),due,p.getString(KEY_ID,"")); else if(due!=0) showReminder(c); }
 static void showReminder(Context c){
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
   Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
   PendingIntent pi=PendingIntent.getActivity(c,1,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   String reason=c.getSharedPreferences(PREF,0).getString(KEY_REASON,"aktivitas");
   String msg="Sudah 10 menit sejak kamu keluar untuk: "+reason+". Buka StoreTrack dan catat MASUK jika sudah kembali.";
   Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"storetrack_reminder_v2"):new Notification.Builder(c);
   b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Swadaya Sarana Plastik: pengingat kembali").setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true).setContentIntent(pi);
   if(Build.VERSION.SDK_INT<26){ b.setSound(null); b.setVibrate(new long[]{0}); b.setPriority(Notification.PRIORITY_LOW); }
   nm.notify(NOTIFICATION_ID,b.build());
 }
 static void show(Context c,String title,String msg){ showReminder(c); }
}
