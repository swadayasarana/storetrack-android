package com.swadaya.storetrack;
import android.content.*;
import android.content.SharedPreferences;
public class ReminderReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ SharedPreferences p=c.getSharedPreferences(ReminderScheduler.PREF,0); long due=p.getLong(ReminderScheduler.KEY_DUE,0); if(due==0 || System.currentTimeMillis()<due)return; ReminderScheduler.showReminder(c); } }
